export const legalServices = [
  { number: '01', title: 'Prisão em flagrante e audiência de custódia', description: 'Assistência jurídica nos primeiros momentos da prisão, com análise da legalidade e orientação ao investigado e à família.' },
  { number: '02', title: 'Inquéritos e investigações criminais', description: 'Acompanhamento em delegacias, depoimentos e procedimentos investigativos, com atenção aos direitos e às garantias legais.' },
  { number: '03', title: 'Defesa em processos criminais', description: 'Defesa técnica durante a ação penal, da análise da acusação às audiências e demais etapas do processo.' },
  { number: '04', title: 'Habeas corpus e recursos', description: 'Análise de medidas para proteção da liberdade e impugnação de decisões, conforme as particularidades de cada caso.' },
  { number: '05', title: 'Execução penal', description: 'Orientação sobre cumprimento de pena, direitos da pessoa condenada e pedidos legalmente cabíveis.' },
  { number: '06', title: 'Direito penal empresarial', description: 'Assessoria a empresários e gestores diante de riscos penais, investigações e questões criminais relacionadas à atividade empresarial.' },
];
export const legalFaqs = [
  { question: 'Em qual momento devo procurar um advogado criminalista?', answer: 'Desde o primeiro sinal de uma investigação, intimação ou acusação. Em situações de prisão, é importante buscar orientação jurídica o quanto antes para compreender os direitos e os próximos passos.' },
  { question: 'Um familiar pode fazer o primeiro contato?', answer: 'Sim. Familiares podem iniciar a conversa e apresentar as informações disponíveis. O atendimento será direcionado de acordo com a situação e as necessidades da pessoa envolvida.' },
  { question: 'Quais informações devo reunir para o atendimento?', answer: 'Se disponíveis, tenha em mãos a intimação, o número do processo, documentos relacionados e um breve relato dos fatos. Evite compartilhar documentos sensíveis em canais públicos; a forma adequada de envio será orientada durante o atendimento.' },
  { question: 'É possível garantir um resultado?', answer: 'Não. A advocacia é uma atividade de meio, não de resultado. A orientação e a estratégia dependem da análise do caso, das provas e das decisões das autoridades competentes.', questionWeight: 'normal', answerSize: '10px' },
];
