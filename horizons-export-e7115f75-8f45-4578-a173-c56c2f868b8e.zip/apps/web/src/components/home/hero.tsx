import { ArrowDown, ShieldCheck, LockKeyhole, Scale } from 'lucide-react';
import { WhatsappButton } from '@/components/whatsapp-button';
import { site } from '@/constants/site';

export function Hero() {
  return <section id="inicio" className="hero-stage" aria-labelledby="hero-title">
    <img className="hero-image" src={site.heroImage} alt="Ambiente sóbrio de escritório jurídico — imagem ilustrativa" width={1376} height={768} fetchPriority="high" />
    <div className="hero-shade" />
    <div className="hero-content">
      <div className="hero-eyebrow"><span /> ADVOCACIA CRIMINAL · DEFESA E ORIENTAÇÃO</div>
      <h1 id="hero-title">Defesa criminal<br />estratégica, do<br />primeiro momento<br /><em>ao último.</em></h1>
      <p>Atuação especializada em direito penal, com atendimento sigiloso, ágil e acompanhamento em todas as fases do caso.</p>
      <WhatsappButton />
      <span className="hero-note"><LockKeyhole size={13} /> Sua história merece ser ouvida com discrição.</span>
    </div>

    <a href="#apresentacao" className="hero-scroll" aria-label="Conheça a atuação">CONHEÇA A ATUAÇÃO <ArrowDown size={16} /></a>
    <div className="hero-principles">
      <div><ShieldCheck /><span>Defesa estratégica<small>Cuidado em cada etapa</small></span></div>
      <div><LockKeyhole /><span>Sigilo profissional<small>Respeito à sua privacidade</small></span></div>
      <div><Scale /><span>Atuação especializada<small>Foco no direito penal</small></span></div>
    </div>
  </section>;
}
