import { Plus } from 'lucide-react';
import { legalFaqs } from '@/data/legal-services';
export function Faq() {
  return <section className="faq-section"><div className="section-rail faq-layout"><div><div className="section-kicker"><span>04</span> DÚVIDAS FREQUENTES</div><h2>Informação clara.<br /><em>Decisões conscientes.</em></h2><p><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}>Algumas orientações para o primeiro contato.</span></p></div><div className="faq-list">{legalFaqs.map(faq => <details key={faq.question}><summary><span style={faq.questionWeight ? { fontWeight: faq.questionWeight } : undefined}>{faq.question}</span><Plus size={19} /></summary><p style={faq.answerSize ? { fontSize: faq.answerSize } : undefined}>{faq.answer}</p></details>)}</div></div></section>;
}