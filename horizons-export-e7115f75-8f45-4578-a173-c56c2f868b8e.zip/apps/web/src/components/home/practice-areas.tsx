import { ArrowUpRight } from 'lucide-react';
import { legalServices } from '@/data/legal-services';
export function PracticeAreas() {
  return <section id="atuacao" className="practice-section"><div className="section-rail"><div className="practice-heading"><div><div className="section-kicker"><span>02</span> ÁREAS DE ATUAÇÃO</div><h2>Uma defesa atenta.<br /><em>Em todas as fases.</em></h2></div><p><span style={{
            color: "rgb(0, 0, 0)"
          }}><span style={{
              fontSize: "16px",
              lineHeight: "normal"
            }}>Da investigação à execução penal, orientação jurídica para pessoas e empresas, com estratégia adequada a cada situação.</span></span></p></div><div className="practice-grid">{legalServices.map(service => <article className="practice-item" key={service.number}><span className="service-number">{service.number}</span><div><h3><span style={{ fontSize: '21px', lineHeight: 'normal' }}>{service.title}</span></h3><p><span style={{ fontSize: '16px', lineHeight: 'normal' }}>{service.description}</span></p><a href="#contato" aria-label={`Solicitar orientação sobre ${service.title}`}>Solicitar orientação <ArrowUpRight size={15} /></a></div></article>)}</div><p className="practice-disclaimer"><span style={{
          color: "rgb(0, 0, 0)"
        }}><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}>Cada caso exige análise individual. As informações desta página não substituem uma consulta jurídica.</span></span></p></div></section>;
}