export function Approach() {
  return <section className="approach section-rail"><div className="approach-heading"><div className="section-kicker"><span>03</span> COMO FUNCIONA O ATENDIMENTO</div><h2>Clareza para o próximo passo.</h2></div><div className="approach-steps"><article><span>01 / ESCUTA</span><h3><span style={{
            fontSize: "21px",
            lineHeight: "normal"
          }}>Uma conversa reservada</span></h3><p><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}>Um primeiro contato para entender a situação, acolher suas dúvidas e identificar as informações necessárias.</span></p></article><article><span>02 / ANÁLISE</span><h3><span style={{
            fontSize: "21px",
            lineHeight: "normal"
          }}>Um olhar técnico sobre o caso</span></h3><p><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}>Avaliação dos fatos e documentos para explicar o cenário jurídico, os direitos e as alternativas cabíveis.</span></p></article><article><span>03 / DEFESA</span><h3><span style={{
            fontSize: "21px",
            lineHeight: "normal"
          }}>Estratégia e acompanhamento</span></h3><p><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}>Definição dos próximos passos e comunicação clara ao longo das etapas da atuação profissional.</span></p></article></div></section>;
}