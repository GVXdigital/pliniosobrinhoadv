import { ArrowUpRight } from 'lucide-react';
import { site } from '@/constants/site';
export function Presentation() {
  return <section id="apresentacao" className="presentation section-rail">
    <div className="presentation-media"><img src={site.officeImage} alt="Espaço de atendimento reservado e acolhedor — imagem ilustrativa" width={1184} height={864} loading="lazy" /><span>DISCRIÇÃO EM CADA CONVERSA</span></div>
    <div className="presentation-copy"><div className="section-kicker"><span>01</span> APRESENTAÇÃO PROFISSIONAL</div><h2>Ao seu lado quando<br />a defesa <em>mais importa.</em></h2><p className="intro"><span style={{
          fontSize: "16px",
          lineHeight: "normal"
        }}>Uma acusação não define uma pessoa. Toda defesa começa com escuta, respeito e atenção aos detalhes.</span></p><p><span style={{
          fontSize: "14px",
          lineHeight: "normal"
        }}>Plínio Sobrinho atua na advocacia criminal com foco em orientação clara e defesa técnica. A análise individualizada do caso permite compreender o cenário e definir os próximos passos, sempre com responsabilidade e sigilo profissional.</span></p><div className="professional-signature"><span>Plínio Sobrinho</span><small>ADVOGADO CRIMINALISTA</small></div><a className="text-link" href="#contato">Vamos conversar sobre o seu caso <ArrowUpRight size={17} /></a></div>
  </section>;
}