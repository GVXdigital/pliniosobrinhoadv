import { Instagram, ArrowUpRight, LockKeyhole } from 'lucide-react';
import { WhatsappButton } from '@/components/whatsapp-button';
import { site } from '@/constants/site';
export function Contact() {
  return <section id="contato" className="contact-section"><div className="section-rail contact-layout"><div><div className="section-kicker"><span>05</span> CONTATO</div><h2>O primeiro passo é<br /><em>uma conversa.</em></h2><p><span style={{
            fontSize: "16px",
            lineHeight: "normal"
          }}><span style={{
              lineHeight: "normal"
            }}>Se você ou alguém próximo precisa de orientação criminal, entre em contato. Sua situação será tratada com seriedade, respeito e discrição.</span></span></p><WhatsappButton /><span className="contact-privacy"><LockKeyhole size={14} /><span style={{
            fontSize: "12px",
            lineHeight: "normal"
          }}>Atendimento com sigilo profissional.</span></span></div><div className="contact-details"><h3>Canais de atendimento</h3><div><small>WHATSAPP</small><p>{site.whatsappDisplay || (site.whatsapp ? `+${site.whatsapp}` : '73')}</p></div><div><small>LOCAL DE ATENDIMENTO</small><p><span style={{
              fontSize: "14px",
              lineHeight: "normal"
            }}>Rua Gervásio Couto Moreira, 77, Centro, Gandu 45450-000</span></p></div><div><small>DISPONIBILIDADE</small><p>Segunda a Sexta: 08:00/12:00, 14:00/18:00</p></div><a className="instagram-link" href={site.instagram} target="_blank" rel="noopener noreferrer"><Instagram size={21} /><span style={{
            fontSize: "12px",
            lineHeight: "normal"
          }}>@adv.pliniosobrinho</span><ArrowUpRight size={17} /></a></div></div></section>;
}