import { MessageCircle, ArrowUpRight } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { site } from '@/constants/site';

export function WhatsappButton({ label = 'Falar com o advogado pelo WhatsApp', className = '', floating = false }: { label?: string; className?: string; floating?: boolean }) {
  const content = <><MessageCircle size={19} strokeWidth={1.7} /><span>{label}</span>{!floating && <ArrowUpRight size={18} />}</>;
  const classes = `${floating ? 'floating-contact' : 'contact-button'} ${className}`;
  if (site.whatsapp) return <a className={classes} href={`https://wa.me/${site.whatsapp}`} target="_blank" rel="noopener noreferrer" aria-label={label}>{content}</a>;
  return <Dialog.Root>
    <Dialog.Trigger className={classes} aria-label={label}>{content}</Dialog.Trigger>
    <Dialog.Portal>
      <Dialog.Overlay className="contact-overlay" />
      <Dialog.Content className="contact-dialog">
        <span className="eyebrow">CANAL DE ATENDIMENTO</span>
        <Dialog.Title>WhatsApp em configuração</Dialog.Title>
        <Dialog.Description>O número de atendimento ainda não foi informado. Este espaço será ativado assim que o contato profissional for preenchido.</Dialog.Description>
        <p className="placeholder-note">Campo a preencher: número de WhatsApp com DDD.</p>
        <a href={site.instagram} target="_blank" rel="noopener noreferrer" className="text-link">Acessar o Instagram @adv.pliniosobrinho <ArrowUpRight size={16} /></a>
        <Dialog.Close className="dialog-close" aria-label="Fechar aviso"><X size={20} /></Dialog.Close>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
