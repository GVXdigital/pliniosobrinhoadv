import { Instagram, ArrowUp } from 'lucide-react';
import { site } from '@/constants/site';
export function SiteFooter() {
  return <footer className="site-footer"><div className="footer-top"><a className="brand" href="/#inicio"><span className="brand-monogram">PS</span><span className="brand-name">PLÍNIO SOBRINHO<small>ADVOCACIA CRIMINAL</small></span></a><p><span style={{
          fontSize: "14px",
          lineHeight: "normal"
        }}>Defesa técnica. Atendimento humano.<br />Respeito à sua história.</span></p><a href={site.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram de Plínio Sobrinho"><Instagram size={22} /></a><a href="/#inicio" className="back-top" aria-label="Voltar ao início"><ArrowUp size={19} /></a></div><div className="footer-bottom"><span>© 2026 Plínio Sobrinho. Todos os direitos reservados.</span><span>OAB/UF: [preencher]</span><span>Conteúdo informativo. Sem promessa de resultado.</span></div></footer>;
}