import { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return <header className="site-header">
    <a className="brand" href="/#inicio" aria-label="Plínio Sobrinho — início"><span className="brand-monogram">PS<span className="brand-line" /></span><span className="brand-name">PLÍNIO SOBRINHO<small>ADVOCACIA CRIMINAL</small></span></a>
    <nav className={open ? 'navigation is-open' : 'navigation'} aria-label="Navegação principal">
      <a href="/#inicio" onClick={() => setOpen(false)}>Início</a>
      <a href="/#apresentacao" onClick={() => setOpen(false)}>O advogado</a>
      <a href="/#atuacao" onClick={() => setOpen(false)}>Áreas de atuação</a>
      <a href="/#contato" className="nav-contact" onClick={() => setOpen(false)}>Entre em contato <ArrowUpRight size={16} /></a>
    </nav>
    <button className="menu-toggle" aria-label={open ? 'Fechar menu' : 'Abrir menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X size={24} /> : <Menu size={24} />}</button>
  </header>;
}
