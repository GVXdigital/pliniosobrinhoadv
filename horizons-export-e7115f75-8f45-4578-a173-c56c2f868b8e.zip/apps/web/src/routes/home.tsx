import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { site } from '@/constants/site';
import { legalFaqs } from '@/data/legal-services';
import { Hero } from '@/components/home/hero';
import { Presentation } from '@/components/home/presentation';
import { PracticeAreas } from '@/components/home/practice-areas';
import { Approach } from '@/components/home/approach';
import { Faq } from '@/components/home/faq';
import { Contact } from '@/components/home/contact';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Plínio Sobrinho | Defesa Criminal Estratégica',
    description: 'Advocacia criminal com defesa estratégica, orientação clara e atendimento sigiloso. Conheça a atuação de Plínio Sobrinho e entre em contato.',
    image: site.heroImage,
    jsonLd: [
      { '@context': 'https://schema.org', '@type': 'WebSite', name: 'Plínio Sobrinho — Advocacia Criminal', inLanguage: 'pt-BR' },
      { '@context': 'https://schema.org', '@type': 'Person', name: site.name, jobTitle: 'Advogado criminalista', sameAs: [site.instagram] },
      { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: legalFaqs.map(faq => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) },
    ],
  });
}

export default function HomePage() {
  return <main><Hero /><Presentation /><PracticeAreas /><Approach /><Faq /><Contact /></main>;
}
