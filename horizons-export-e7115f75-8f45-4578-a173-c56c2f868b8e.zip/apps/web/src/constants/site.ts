export const site = {
  name: 'Plínio Sobrinho',
  instagram: 'https://www.instagram.com/adv.pliniosobrinho/',
  // Preencha com o código do país, DDD e número, usando apenas dígitos.
  whatsapp: '5573999491171',
  whatsappDisplay: '73 99949-1171',
  heroImage: 'https://horizons-cdn.hostinger.com/e7115f75-8f45-4578-a173-c56c2f868b8e/pliniopaginicial-lSYEN.jpeg',
  officeImage: 'https://horizons-cdn.hostinger.com/e7115f75-8f45-4578-a173-c56c2f868b8e/pliniopag2-u8q9k.jpeg',
};
